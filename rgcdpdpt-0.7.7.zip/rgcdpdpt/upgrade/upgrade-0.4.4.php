<?php
function upgrade_module_0_4_4($module)
{
    return true;
}
