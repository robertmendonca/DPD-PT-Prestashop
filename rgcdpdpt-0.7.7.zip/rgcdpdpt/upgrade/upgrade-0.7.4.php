<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_7_4($module)
{
    if (!class_exists('DpdConfig')) {
        require_once dirname(__DIR__) . '/classes/DpdConfig.php';
    }

    if (!class_exists('DpdCarrierManager')) {
        require_once dirname(__DIR__) . '/classes/DpdCarrierManager.php';
    }

    DpdConfig::ensureDefaults();

    return (new DpdCarrierManager($module))->installOrRepair();
}
