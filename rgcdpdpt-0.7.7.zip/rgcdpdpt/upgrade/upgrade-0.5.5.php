<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_5_5($module)
{
    DpdConfig::ensureDefaults();
    return true;
}
