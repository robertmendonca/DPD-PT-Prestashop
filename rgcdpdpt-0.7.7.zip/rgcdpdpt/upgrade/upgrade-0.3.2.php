<?php
function upgrade_module_0_3_2($module)
{
    return (bool) require dirname(__DIR__) . '/sql/install.php';
}
