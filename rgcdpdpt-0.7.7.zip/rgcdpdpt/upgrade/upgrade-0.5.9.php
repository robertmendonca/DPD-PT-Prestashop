<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_5_9($module)
{
    return DpdConfig::ensureDefaults();
}
