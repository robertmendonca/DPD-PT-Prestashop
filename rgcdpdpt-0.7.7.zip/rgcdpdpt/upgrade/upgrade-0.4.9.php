<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_0_4_9($module)
{
    return true;
}
