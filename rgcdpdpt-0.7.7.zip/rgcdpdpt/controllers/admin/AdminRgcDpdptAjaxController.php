<?php
class AdminRgcDpdptAjaxController extends ModuleAdminController
{
    public $bootstrap = true;

    public function postProcess()
    {
        $action = Tools::getValue('action');

        if ($action === 'CreateShipment') {
            $idOrder = (int) Tools::getValue('id_order');

            try {
                (new DpdShipmentService($this->module))->createForOrder($idOrder);
                $this->context->cookie->__set('rgcdpdpt_flash_success', 'Expedição DPD criada com sucesso.');
            } catch (Exception $e) {
                DpdLogRepository::add('error', $e->getMessage(), 'order', $idOrder);
                $this->context->cookie->__set('rgcdpdpt_flash_error', $e->getMessage());
            }

            Tools::redirectAdmin($this->context->link->getAdminLink('AdminOrders', true, [], [
                'id_order' => $idOrder,
                'vieworder' => 1,
            ]));
        }


        if ($action === 'RefreshTracking') {
            $idOrder = (int) Tools::getValue('id_order');

            try {
                $tracking = (new DpdShipmentService($this->module))->refreshTrackingForOrder($idOrder);
                $this->context->cookie->__set('rgcdpdpt_flash_success', 'Guia DPD recuperada: ' . $tracking);
            } catch (Exception $e) {
                DpdLogRepository::add('error', $e->getMessage(), 'order', $idOrder);
                $this->context->cookie->__set('rgcdpdpt_flash_error', $e->getMessage());
            }

            Tools::redirectAdmin($this->context->link->getAdminLink('AdminOrders', true, [], [
                'id_order' => $idOrder,
                'vieworder' => 1,
            ]));
        }


        if ($action === 'SetManualTracking') {
            $idOrder = (int) Tools::getValue('id_order');
            $trackingNumber = (string) Tools::getValue('tracking_number');

            try {
                $tracking = (new DpdShipmentService($this->module))->setManualTrackingForOrder($idOrder, $trackingNumber);
                $this->context->cookie->__set('rgcdpdpt_flash_success', 'Guia DPD gravada: ' . $tracking);
            } catch (Exception $e) {
                DpdLogRepository::add('error', $e->getMessage(), 'order', $idOrder);
                $this->context->cookie->__set('rgcdpdpt_flash_error', $e->getMessage());
            }

            Tools::redirectAdmin($this->context->link->getAdminLink('AdminOrders', true, [], [
                'id_order' => $idOrder,
                'vieworder' => 1,
            ]));
        }

        if ($action === 'DownloadLabel') {
            $idOrder = (int) Tools::getValue('id_order');
            $shipment = DpdShipmentRepository::getByOrderId($idOrder);
            if (!$shipment || empty($shipment['label_path']) || !is_file($shipment['label_path'])) {
                die('Label not found');
            }

            header('Content-Type: application/pdf');
            header('Content-Disposition: inline; filename="dpd-label-order-' . $idOrder . '.pdf"');
            readfile($shipment['label_path']);
            exit;
        }

        parent::postProcess();
    }
}
