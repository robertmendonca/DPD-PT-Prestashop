<?php
class RgcdpdptPickupModuleFrontController extends ModuleFrontController
{
    public $ssl = true;
    public $ajax = true;

    public function postProcess()
    {
        $action = Tools::getValue('action');

        try {
            if ($action === 'list') {
                $zipCode = trim((string) Tools::getValue('zip'));
                if ($zipCode === '') {
                    $this->ajaxRender(json_encode(['ok' => false, 'message' => 'Missing zip code']));
                    return;
                }

                $deliveryAddress = '';
                $deliveryCity = '';
                $countryCode = 'PRT';

                if (isset($this->context->cart) && Validate::isLoadedObject($this->context->cart) && (int) $this->context->cart->id_address_delivery > 0) {
                    $address = new Address((int) $this->context->cart->id_address_delivery);
                    if (Validate::isLoadedObject($address)) {
                        $deliveryAddress = trim((string) $address->address1 . ' ' . (string) $address->address2);
                        $deliveryCity = (string) $address->city;
                        $country = new Country((int) $address->id_country);
                        if (Validate::isLoadedObject($country)) {
                            $countryCode = $this->iso2ToIso3((string) $country->iso_code);
                        }
                    }
                }

                $deliveryAddress = trim((string) Tools::getValue('address', $deliveryAddress));
                $deliveryCity = trim((string) Tools::getValue('city', $deliveryCity));

                $items = (new DpdPickupClient())->search($zipCode, $countryCode, $deliveryAddress, $deliveryCity);
                $this->ajaxRender(json_encode(['ok' => true, 'items' => $items]));
                return;
            }

            if ($action === 'save') {
                $cart = $this->context->cart;
                if (!Validate::isLoadedObject($cart)) {
                    $this->ajaxRender(json_encode(['ok' => false, 'message' => 'Cart not found']));
                    return;
                }

                $payload = [
                    'code' => Tools::getValue('pickup_code'),
                    'name' => Tools::getValue('pickup_name'),
                    'address' => Tools::getValue('pickup_address'),
                    'zip' => Tools::getValue('pickup_zip'),
                    'city' => Tools::getValue('pickup_city'),
                    'country' => Tools::getValue('pickup_country'),
                    'latitude' => Tools::getValue('pickup_latitude'),
                    'longitude' => Tools::getValue('pickup_longitude'),
                ];

                if (empty($payload['code']) || empty($payload['name'])) {
                    $this->ajaxRender(json_encode(['ok' => false, 'message' => 'Invalid pickup point']));
                    return;
                }

                DpdPickupRepository::saveForCart((int) $cart->id, $payload);
                $this->ajaxRender(json_encode(['ok' => true]));
                return;
            }

            $this->ajaxRender(json_encode(['ok' => false, 'message' => 'Invalid action']));
        } catch (Exception $e) {
            DpdLogRepository::add('error', $e->getMessage(), 'pickup', 0);
            $this->ajaxRender(json_encode(['ok' => false, 'message' => $e->getMessage()]));
        }
    }
    protected function iso2ToIso3($iso2)
    {
        $iso2 = Tools::strtoupper(trim((string) $iso2));
        $map = [
            'PT' => 'PRT',
            'ES' => 'ESP',
            'FR' => 'FRA',
            'DE' => 'DEU',
            'IT' => 'ITA',
            'NL' => 'NLD',
            'BE' => 'BEL',
            'LU' => 'LUX',
            'IE' => 'IRL',
            'GB' => 'GBR',
            'UK' => 'GBR',
        ];

        return $map[$iso2] ?? ($iso2 ?: 'PRT');
    }

}
