(function () {
  'use strict';

  var LEAFLET_CSS_URL = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
  var MODULE_VERSION = '0.4.7';
  var LEAFLET_JS_URL = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';

  function postForm(endpoint, payload) {
    return fetch(endpoint, {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
      body: payload.toString()
    });
  }

  function escapeHtml(value) {
    return String(value || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function parseCoordinate(value) {
    if (value === null || typeof value === 'undefined') {
      return null;
    }

    var normalized = String(value).replace(',', '.').replace(/[^0-9.\-]/g, '');
    var number = parseFloat(normalized);

    if (!isFinite(number)) {
      return null;
    }

    return number;
  }

  function itemHasCoordinates(item) {
    return parseCoordinate(item.latitude) !== null && parseCoordinate(item.longitude) !== null;
  }

  function loadCssOnce(url, id) {
    if (document.getElementById(id)) {
      return;
    }

    var link = document.createElement('link');
    link.id = id;
    link.rel = 'stylesheet';
    link.href = url;
    document.head.appendChild(link);
  }

  function loadScriptOnce(url, id) {
    if (window.L) {
      return Promise.resolve();
    }

    if (window.rgcdpdptLeafletLoading) {
      return window.rgcdpdptLeafletLoading;
    }

    window.rgcdpdptLeafletLoading = new Promise(function (resolve, reject) {
      var existing = document.getElementById(id);
      if (existing) {
        existing.addEventListener('load', resolve);
        existing.addEventListener('error', reject);
        return;
      }

      var script = document.createElement('script');
      script.id = id;
      script.src = url;
      script.async = true;
      script.onload = resolve;
      script.onerror = reject;
      document.head.appendChild(script);
    });

    return window.rgcdpdptLeafletLoading;
  }

  function loadLeaflet() {
    loadCssOnce(LEAFLET_CSS_URL, 'rgcdpdpt-leaflet-css');
    return loadScriptOnce(LEAFLET_JS_URL, 'rgcdpdpt-leaflet-js');
  }

  function normalizeCarrierValue(value) {
    return String(value || '').replace(/[^0-9,]/g, '');
  }

  function selectedCarrierLooksLikePickup(widget) {
    var pickupCarrierId = String(widget.getAttribute('data-pickup-carrier-id') || '');
    var radios = document.querySelectorAll('input[type="radio"][name^="delivery_option"]');
    var checked = null;

    for (var i = 0; i < radios.length; i += 1) {
      if (radios[i].checked) {
        checked = radios[i];
        break;
      }
    }

    if (!checked) {
      return false;
    }

    var selectedValue = normalizeCarrierValue(checked.value);
    if (pickupCarrierId && selectedValue.split(',').indexOf(pickupCarrierId) !== -1) {
      return true;
    }

    var row = checked.closest('.delivery-option, .carrier-line, .js-delivery-option, .delivery-options-list, .row');
    var text = row ? row.textContent : '';
    return /DPD\s*Pickup|Pickup\s*DPD|ponto\s*Pickup/i.test(text || '');
  }

  function revealWidgetAncestors(widget) {
    if (!widget) {
      return;
    }

    widget.style.display = 'block';
    widget.style.visibility = 'visible';
    widget.style.opacity = '1';

    var parent = widget.parentElement;
    var depth = 0;
    while (parent && depth < 4) {
      var className = String(parent.className || '');
      if (/carrier-extra-content|rgcdpdpt|pickup/i.test(className)) {
        parent.style.display = 'block';
        parent.style.visibility = 'visible';
        parent.style.opacity = '1';
      }
      parent = parent.parentElement;
      depth += 1;
    }
  }

  function refreshFallbackVisibility() {
    var primaryWidget = document.querySelector('.rgcdpdpt-pickup-widget[data-is-fallback="0"]');
    var fallbackWidgets = document.querySelectorAll('.rgcdpdpt-pickup-widget[data-is-fallback="1"]');

    if (primaryWidget) {
      revealWidgetAncestors(primaryWidget);
      fallbackWidgets.forEach(function (widget) {
        widget.style.display = 'none';
      });
      return;
    }

    fallbackWidgets.forEach(function (widget) {
      // Keep fallback visible by default. This avoids a blank checkout when a theme/cache
      // prevents the carrier-specific extra-content block from opening.
      widget.style.display = 'block';
      revealWidgetAncestors(widget);

      if (selectedCarrierLooksLikePickup(widget)) {
        widget.setAttribute('data-pickup-selected', '1');
      } else {
        widget.setAttribute('data-pickup-selected', '0');
      }
    });
  }

  function bindWidget(widget) {
    if (!widget || widget.dataset.rgcdpdptBound === '1') {
      return;
    }

    widget.dataset.rgcdpdptBound = '1';

    var endpoint = widget.getAttribute('data-pickup-url');
    var selectedCode = widget.getAttribute('data-selected-code') || '';
    var lookupBtn = widget.querySelector('#rgcdpdpt_lookup_btn');
    var zipInput = widget.querySelector('#rgcdpdpt_zip_lookup');
    var results = widget.querySelector('#rgcdpdpt_pickup_results');
    var summary = widget.querySelector('#rgcdpdpt_selected_summary');
    var selectWrap = widget.querySelector('#rgcdpdpt_pickup_selector_wrap');
    var select = widget.querySelector('#rgcdpdpt_pickup_select');
    var mapWrap = widget.querySelector('#rgcdpdpt_pickup_map_wrap');
    var mapContainer = widget.querySelector('#rgcdpdpt_pickup_map');

    if (!endpoint || !lookupBtn || !zipInput || !results || !summary || !selectWrap || !select || !mapWrap || !mapContainer) {
      return;
    }

    var pickupItems = [];
    var map = null;
    var markerGroup = null;
    var markersByCode = {};

    function setHidden(id, value) {
      var node = widget.querySelector('#' + id);
      if (node) {
        node.value = value || '';
      }
    }

    function resetSelect(message) {
      select.innerHTML = '<option value="">' + escapeHtml(message || 'Pesquise um código postal para carregar os pontos Pickup') + '</option>';
      select.disabled = true;
      selectWrap.style.display = 'block';
    }

    function setMapPlaceholder(message) {
      if (map && markerGroup) {
        markerGroup.clearLayers();
      }
      mapContainer.innerHTML = '<div class="rgcdpdpt-map-placeholder">' + escapeHtml(message || 'O mapa será carregado depois da pesquisa.') + '</div>';
      mapWrap.style.display = 'block';
    }

    function labelForItem(item) {
      var parts = [];
      if (item.name) {
        parts.push(item.name);
      }
      if (item.address) {
        parts.push(item.address);
      }
      if (item.zip || item.city) {
        parts.push(((item.zip || '') + ' ' + (item.city || '')).trim());
      }
      return parts.join(' - ') || 'DPD Pickup';
    }

    function getItemByCode(code) {
      for (var i = 0; i < pickupItems.length; i += 1) {
        if (String(pickupItems[i].code || '') === String(code || '')) {
          return pickupItems[i];
        }
      }
      return null;
    }

    function saveSelection(item) {
      setHidden('rgcdpdpt_pickup_code', item.code);
      setHidden('rgcdpdpt_pickup_name', item.name);
      setHidden('rgcdpdpt_pickup_address', item.address);
      setHidden('rgcdpdpt_pickup_zip', item.zip);
      setHidden('rgcdpdpt_pickup_city', item.city);
      setHidden('rgcdpdpt_pickup_country', item.country || 'PRT');
      setHidden('rgcdpdpt_pickup_latitude', item.latitude);
      setHidden('rgcdpdpt_pickup_longitude', item.longitude);

      selectedCode = item.code || '';
      widget.setAttribute('data-selected-code', selectedCode);
      summary.innerHTML = '<strong>Ponto selecionado:</strong> ' + escapeHtml(item.name) + ' (' + escapeHtml(item.code) + ')';

      var formData = new URLSearchParams();
      formData.append('ajax', '1');
      formData.append('action', 'save');
      formData.append('pickup_code', item.code || '');
      formData.append('pickup_name', item.name || '');
      formData.append('pickup_address', item.address || '');
      formData.append('pickup_zip', item.zip || '');
      formData.append('pickup_city', item.city || '');
      formData.append('pickup_country', item.country || 'PRT');
      formData.append('pickup_latitude', item.latitude || '');
      formData.append('pickup_longitude', item.longitude || '');

      postForm(endpoint, formData).catch(function () {
        results.innerHTML = '<div class="alert alert-danger">Não foi possível guardar o ponto Pickup selecionado.</div>';
      });
    }

    function focusMapOnItem(item, openPopup) {
      if (!map || !item || !itemHasCoordinates(item)) {
        return;
      }

      var lat = parseCoordinate(item.latitude);
      var lng = parseCoordinate(item.longitude);
      map.setView([lat, lng], 16, {animate: true});
      setTimeout(function () {
        map.invalidateSize();
      }, 120);

      if (openPopup && markersByCode[item.code]) {
        markersByCode[item.code].openPopup();
      }
    }

    function selectItem(item, persist, openPopup) {
      if (!item) {
        return;
      }

      select.value = item.code || '';
      focusMapOnItem(item, openPopup);

      if (persist) {
        saveSelection(item);
      }
    }

    function renderSelect(items) {
      var html = '<option value="">Selecione um ponto Pickup</option>';
      items.forEach(function (item) {
        html += '<option value="' + escapeHtml(item.code || '') + '"'
          + ' data-latitude="' + escapeHtml(item.latitude || '') + '"'
          + ' data-longitude="' + escapeHtml(item.longitude || '') + '">'
          + escapeHtml(labelForItem(item))
          + '</option>';
      });

      select.innerHTML = html;
      select.disabled = false;
      selectWrap.style.display = 'block';
    }

    function renderMap(items) {
      var pointsWithCoordinates = items.filter(itemHasCoordinates);

      if (!pointsWithCoordinates.length) {
        setMapPlaceholder('A DPD devolveu pontos Pickup, mas sem coordenadas para apresentar no mapa. Use a lista acima.');
        results.innerHTML += '<div class="alert alert-warning rgcdpdpt-map-warning">A DPD devolveu pontos Pickup sem coordenadas. A seleção pela lista continua disponível.</div>';
        return;
      }

      mapWrap.style.display = 'block';
      mapContainer.innerHTML = '';

      loadLeaflet()
        .then(function () {
          if (!window.L) {
            throw new Error('Leaflet indisponível.');
          }

          if (!map) {
            map = window.L.map(mapContainer, {
              scrollWheelZoom: false
            });

            window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
              maxZoom: 19,
              attribution: '&copy; OpenStreetMap contributors'
            }).addTo(map);
          }

          if (markerGroup) {
            markerGroup.clearLayers();
          } else {
            markerGroup = window.L.layerGroup().addTo(map);
          }

          markersByCode = {};
          var bounds = [];

          pointsWithCoordinates.forEach(function (item) {
            var lat = parseCoordinate(item.latitude);
            var lng = parseCoordinate(item.longitude);
            var popup = '<strong>' + escapeHtml(item.name || 'DPD Pickup') + '</strong><br>'
              + escapeHtml(item.address || '') + '<br>'
              + escapeHtml(((item.zip || '') + ' ' + (item.city || '')).trim())
              + '<br><button type="button" class="btn btn-sm btn-primary rgcdpdpt-map-select" data-code="' + escapeHtml(item.code || '') + '">Selecionar este ponto</button>';

            var marker = window.L.marker([lat, lng]).bindPopup(popup);
            marker.on('click', function () {
              selectItem(item, false, false);
            });
            marker.addTo(markerGroup);
            markersByCode[item.code] = marker;
            bounds.push([lat, lng]);
          });

          if (bounds.length === 1) {
            map.setView(bounds[0], 15);
          } else {
            map.fitBounds(bounds, {padding: [30, 30]});
          }

          setTimeout(function () {
            map.invalidateSize();
          }, 150);

          if (selectedCode) {
            selectItem(getItemByCode(selectedCode), false, true);
          }
        })
        .catch(function () {
          setMapPlaceholder('Não foi possível carregar o mapa. Use a lista acima para selecionar o ponto Pickup.');
          results.innerHTML += '<div class="alert alert-warning rgcdpdpt-map-warning">Não foi possível carregar o mapa. A seleção pela lista continua disponível.</div>';
        });
    }

    function renderItems(items) {
      pickupItems = Array.isArray(items) ? items : [];
      markersByCode = {};

      if (!pickupItems.length) {
        resetSelect('Nenhum ponto Pickup encontrado');
        setMapPlaceholder('Nenhum ponto Pickup encontrado para este código postal.');
        results.innerHTML = '<div class="alert alert-warning">Nenhum ponto Pickup encontrado.</div>';
        return;
      }

      results.innerHTML = '<div class="alert alert-success">Foram encontrados ' + pickupItems.length + ' pontos Pickup. Selecione na lista ou diretamente no mapa.</div>';
      renderSelect(pickupItems);
      renderMap(pickupItems);

      if (selectedCode && getItemByCode(selectedCode)) {
        select.value = selectedCode;
      }
    }

    resetSelect();
    setMapPlaceholder();

    lookupBtn.addEventListener('click', function () {
      var zip = (zipInput.value || '').trim();
      if (!zip) {
        results.innerHTML = '<div class="alert alert-warning">Indique um código postal.</div>';
        return;
      }

      results.innerHTML = '<div class="alert alert-info">A procurar pontos Pickup...</div>';
      resetSelect('A procurar pontos Pickup...');
      setMapPlaceholder('A procurar pontos Pickup...');

      var query = new URLSearchParams();
      query.append('ajax', '1');
      query.append('action', 'list');
      query.append('zip', zip);

      postForm(endpoint, query)
        .then(function (response) {
          return response.json();
        })
        .then(function (json) {
          if (!json.ok) {
            throw new Error(json.message || 'Erro ao consultar pontos Pickup.');
          }
          renderItems(json.items || []);
        })
        .catch(function (error) {
          resetSelect('Erro ao carregar pontos Pickup');
          setMapPlaceholder('Erro ao carregar pontos Pickup.');
          results.innerHTML = '<div class="alert alert-danger">' + escapeHtml(error.message) + '</div>';
        });
    });

    select.addEventListener('change', function () {
      var item = getItemByCode(select.value);
      selectItem(item, true, true);
    });

    mapContainer.addEventListener('click', function (event) {
      var button = event.target.closest('.rgcdpdpt-map-select');
      if (!button) {
        return;
      }

      var item = getItemByCode(button.getAttribute('data-code'));
      selectItem(item, true, true);
    });

    zipInput.addEventListener('keydown', function (event) {
      if (event.key === 'Enter') {
        event.preventDefault();
        lookupBtn.click();
      }
    });
  }

  function removeDuplicateFallbackWhenPrimaryExists() {
    var primaryWidget = document.querySelector('.rgcdpdpt-pickup-widget[data-is-fallback="0"]');
    if (!primaryWidget) {
      return;
    }

    document.querySelectorAll('.rgcdpdpt-pickup-widget[data-is-fallback="1"]').forEach(function (widget) {
      widget.style.display = 'none';
    });
  }

  function initWidgets() {
    document.querySelectorAll('.rgcdpdpt-pickup-widget').forEach(function (widget) { revealWidgetAncestors(widget); bindWidget(widget); });
    removeDuplicateFallbackWhenPrimaryExists();
    refreshFallbackVisibility();
  }

  document.addEventListener('DOMContentLoaded', initWidgets);
  document.addEventListener('change', function (event) {
    if (event.target && event.target.matches('input[type="radio"][name^="delivery_option"]')) {
      refreshFallbackVisibility();
    }
  });

  if (window.prestashop && typeof window.prestashop.on === 'function') {
    window.prestashop.on('updatedDeliveryForm', initWidgets);
    window.prestashop.on('updatedCheckout', initWidgets);
    window.prestashop.on('changedCheckoutStep', initWidgets);
  }

  var observer = new MutationObserver(function () {
    initWidgets();
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });
})();
