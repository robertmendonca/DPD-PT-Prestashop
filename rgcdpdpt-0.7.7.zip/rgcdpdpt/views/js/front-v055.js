(function () {
  'use strict';

  var LEAFLET_CSS_URL = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.css';
  var MODULE_VERSION = '0.7.4';
  var LEAFLET_JS_URL = 'https://unpkg.com/leaflet@1.9.4/dist/leaflet.js';

  function postForm(endpoint, payload) {
    return fetch(endpoint, {
      method: 'POST',
      headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
      body: payload.toString()
    });
  }

  function escapeHtml(value) {
    return String(value || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function parseCoordinate(value) {
    if (value === null || typeof value === 'undefined') {
      return null;
    }

    var normalized = String(value).replace(',', '.').replace(/[^0-9.\-]/g, '');
    var number = parseFloat(normalized);

    if (!isFinite(number)) {
      return null;
    }

    return number;
  }

  function itemHasCoordinates(item) {
    return parseCoordinate(item.latitude) !== null && parseCoordinate(item.longitude) !== null;
  }

  function formatDistance(value) {
    if (value === null || typeof value === 'undefined' || value === '') {
      return '';
    }

    var km = parseCoordinate(value);
    if (km === null) {
      return '';
    }

    if (km < 1) {
      return Math.round(km * 1000) + ' m';
    }

    return km.toLocaleString('pt-PT', {minimumFractionDigits: 0, maximumFractionDigits: 2}) + ' km';
  }


  function postcodeDigits(value) {
    return String(value || '').replace(/[^0-9]/g, '');
  }

  function postcodeProximityScore(requestedZip, shopZip) {
    var requested = postcodeDigits(requestedZip).slice(0, 7);
    var shop = postcodeDigits(shopZip).slice(0, 7);

    if (requested.length < 7 || shop.length < 7) {
      return {group: 9, diff: Number.MAX_SAFE_INTEGER};
    }

    if (requested === shop) {
      return {group: 0, diff: 0};
    }

    var fullDiff = Math.abs(parseInt(requested, 10) - parseInt(shop, 10));

    if (requested.slice(0, 4) === shop.slice(0, 4)) {
      return {
        group: 1,
        diff: Math.abs(parseInt(requested.slice(4), 10) - parseInt(shop.slice(4), 10))
      };
    }

    if (requested.slice(0, 3) === shop.slice(0, 3)) {
      return {group: 2, diff: fullDiff};
    }

    if (requested.slice(0, 2) === shop.slice(0, 2)) {
      return {group: 3, diff: fullDiff};
    }

    return {group: 4, diff: fullDiff};
  }

  function sortItemsByPostcodeProximity(items, requestedZip) {
    var requestedDigits = postcodeDigits(requestedZip);
    if (!Array.isArray(items) || requestedDigits.length < 7) {
      return Array.isArray(items) ? items : [];
    }

    var hasShopPostcode = items.some(function (item) {
      return postcodeDigits(item && item.zip).length >= 7;
    });

    if (!hasShopPostcode) {
      return items;
    }

    return items.slice().sort(function (a, b) {
      var as = postcodeProximityScore(requestedDigits, a && a.zip);
      var bs = postcodeProximityScore(requestedDigits, b && b.zip);

      if (as.group !== bs.group) {
        return as.group - bs.group;
      }

      if (as.diff !== bs.diff) {
        return as.diff - bs.diff;
      }

      var ad = parseCoordinate(a && a.distance);
      var bd = parseCoordinate(b && b.distance);
      ad = ad === null ? Number.MAX_VALUE : ad;
      bd = bd === null ? Number.MAX_VALUE : bd;

      if (ad !== bd) {
        return ad - bd;
      }

      return 0;
    });
  }

  function loadCssOnce(url, id) {
    if (document.getElementById(id)) {
      return;
    }

    var link = document.createElement('link');
    link.id = id;
    link.rel = 'stylesheet';
    link.href = url;
    document.head.appendChild(link);
  }

  function loadScriptOnce(url, id) {
    if (window.L) {
      return Promise.resolve();
    }

    if (window.rgcdpdptLeafletLoading) {
      return window.rgcdpdptLeafletLoading;
    }

    window.rgcdpdptLeafletLoading = new Promise(function (resolve, reject) {
      var existing = document.getElementById(id);
      if (existing) {
        existing.addEventListener('load', resolve);
        existing.addEventListener('error', reject);
        return;
      }

      var script = document.createElement('script');
      script.id = id;
      script.src = url;
      script.async = true;
      script.onload = resolve;
      script.onerror = reject;
      document.head.appendChild(script);
    });

    return window.rgcdpdptLeafletLoading;
  }

  function loadLeaflet() {
    loadCssOnce(LEAFLET_CSS_URL, 'rgcdpdpt-leaflet-css');
    return loadScriptOnce(LEAFLET_JS_URL, 'rgcdpdpt-leaflet-js');
  }

  function normalizeCarrierValue(value) {
    return String(value || '').replace(/[^0-9,]/g, '');
  }

  function selectedCarrierLooksLikePickup(widget) {
    var pickupCarrierId = String(widget.getAttribute('data-pickup-carrier-id') || '');
    var radios = document.querySelectorAll('input[type="radio"][name^="delivery_option"]');
    var checked = null;

    for (var i = 0; i < radios.length; i += 1) {
      if (radios[i].checked) {
        checked = radios[i];
        break;
      }
    }

    if (!checked) {
      return false;
    }

    var values = normalizeCarrierValue(checked.value).split(',').filter(Boolean);
    if (pickupCarrierId && values.indexOf(pickupCarrierId) !== -1) {
      return true;
    }

    var text = '';
    var row = checked.closest('.delivery-option, .carrier-line, .js-delivery-option, .delivery-options-list, .row, li');
    if (row) {
      text += ' ' + row.textContent;
    }
    if (checked.id) {
      var safeId = checked.id.replace(/"/g, '\\"');
      var label = document.querySelector('label[for="' + safeId + '"]');
      if (label) {
        text += ' ' + label.textContent;
      }
    }

    return /DPD\s*Pickup|Pickup\s*DPD|ponto\s*Pickup/i.test(text || '');
  }
  function revealWidgetAncestors(widget) {
    if (!widget) {
      return;
    }

    widget.style.display = 'block';
    widget.style.visibility = 'visible';
    widget.style.opacity = '1';

    var parent = widget.parentElement;
    var depth = 0;
    while (parent && depth < 4) {
      var className = String(parent.className || '');
      if (/carrier-extra-content|rgcdpdpt|pickup/i.test(className)) {
        parent.style.display = 'block';
        parent.style.visibility = 'visible';
        parent.style.opacity = '1';
      }
      parent = parent.parentElement;
      depth += 1;
    }
  }

  function setPickupWidgetVisible(widget, visible) {
    if (!widget) {
      return;
    }

    if (visible) {
      widget.classList.add('rgcdpdpt-pickup-active');
      widget.style.display = 'block';
      widget.style.visibility = 'visible';
      widget.style.opacity = '1';
      revealWidgetAncestors(widget);
      setTimeout(function () {
        window.dispatchEvent(new Event('resize'));
      }, 120);
    } else {
      widget.classList.remove('rgcdpdpt-pickup-active');
      widget.style.display = 'none';
    }
  }

  function updatePickupWidgetVisibility(widget) {
    setPickupWidgetVisible(widget, selectedCarrierLooksLikePickup(widget));
  }

  function refreshFallbackVisibility() {
    var primaryWidget = document.querySelector('.rgcdpdpt-pickup-widget[data-is-fallback="0"]');
    var fallbackWidgets = document.querySelectorAll('.rgcdpdpt-pickup-widget[data-is-fallback="1"]');

    if (primaryWidget) {
      updatePickupWidgetVisibility(primaryWidget);
      fallbackWidgets.forEach(function (widget) {
        if (widget.parentNode) {
          widget.parentNode.removeChild(widget);
        } else {
          widget.style.display = 'none';
        }
      });
      return;
    }

    fallbackWidgets.forEach(function (widget) {
      widget.style.display = 'none';
    });
  }

  function bindWidget(widget) {
    if (!widget || widget.dataset.rgcdpdptBound === '1') {
      return;
    }

    widget.dataset.rgcdpdptBound = '1';

    var endpoint = widget.getAttribute('data-pickup-url');
    var selectedCode = widget.getAttribute('data-selected-code') || '';
    var deliveryAddress = widget.getAttribute('data-delivery-address') || '';
    var deliveryCity = widget.getAttribute('data-delivery-city') || '';
    var lookupBtn = widget.querySelector('#rgcdpdpt_lookup_btn');
    var zipInput = widget.querySelector('#rgcdpdpt_zip_lookup');
    var results = widget.querySelector('#rgcdpdpt_pickup_results');
    var summary = widget.querySelector('#rgcdpdpt_selected_summary');
    var selectWrap = widget.querySelector('#rgcdpdpt_pickup_selector_wrap');
    var select = widget.querySelector('#rgcdpdpt_pickup_select');
    var mapWrap = widget.querySelector('#rgcdpdpt_pickup_map_wrap');
    var mapContainer = widget.querySelector('#rgcdpdpt_pickup_map');
    var mapTools = widget.querySelector('#rgcdpdpt_map_tools');
    var zoomInBtn = widget.querySelector('#rgcdpdpt_map_zoom_in');
    var zoomOutBtn = widget.querySelector('#rgcdpdpt_map_zoom_out');
    var fitBtn = widget.querySelector('#rgcdpdpt_map_fit');
    var selectedBtn = widget.querySelector('#rgcdpdpt_map_selected');
    var pickupMarkerIconUrl = widget.getAttribute('data-pickup-marker-icon') || '';

    if (!endpoint || !lookupBtn || !zipInput || !results || !summary || !selectWrap || !select || !mapWrap || !mapContainer) {
      return;
    }

    var pickupItems = [];
    var map = null;
    var markerGroup = null;
    var markersByCode = {};
    var lastBounds = [];

    function setHidden(id, value) {
      var node = widget.querySelector('#' + id);
      if (node) {
        node.value = value || '';
      }
    }

    function setMapToolsVisible(visible) {
      if (!mapTools) {
        return;
      }

      mapTools.style.display = visible ? 'flex' : 'none';
    }

    function updateMapActionState() {
      if (selectedBtn) {
        selectedBtn.disabled = !(select && select.value && getItemByCode(select.value));
      }
    }

    function fitMapToCurrentBounds() {
      if (!map || !lastBounds.length) {
        return;
      }

      if (lastBounds.length === 1) {
        map.setView(lastBounds[0], 17, {animate: true});
      } else {
        map.fitBounds(lastBounds, {padding: [42, 42], maxZoom: 16, animate: true});
      }

      setTimeout(function () {
        map.invalidateSize();
      }, 120);
    }

    function resetSelect(message) {
      select.innerHTML = '<option value="">' + escapeHtml(message || 'Pesquise um código postal para carregar os pontos Pickup') + '</option>';
      select.disabled = true;
      selectWrap.style.display = 'block';
      updateMapActionState();
    }

    function destroyMap() {
      if (map && typeof map.remove === 'function') {
        map.remove();
      }
      map = null;
      markerGroup = null;
      markersByCode = {};
    }

    function setMapPlaceholder(message) {
      destroyMap();
      lastBounds = [];
      setMapToolsVisible(false);
      updateMapActionState();
      mapContainer.innerHTML = '<div class="rgcdpdpt-map-placeholder">' + escapeHtml(message || 'O mapa será carregado depois da pesquisa.') + '</div>';
      mapWrap.style.display = 'block';
    }

    function labelForItem(item) {
      var parts = [];
      if (item.name) {
        parts.push(item.name);
      }
      if (item.address) {
        parts.push(item.address);
      }
      if (item.zip || item.city) {
        parts.push(((item.zip || '') + ' ' + (item.city || '')).trim());
      }
      var formattedDistance = formatDistance(item.distance);
      if (formattedDistance) {
        parts.push(formattedDistance);
      }
      return parts.join(' - ') || 'DPD Pickup';
    }

    function getItemByCode(code) {
      for (var i = 0; i < pickupItems.length; i += 1) {
        if (String(pickupItems[i].code || '') === String(code || '')) {
          return pickupItems[i];
        }
      }
      return null;
    }

    function saveSelection(item) {
      setHidden('rgcdpdpt_pickup_code', item.code);
      setHidden('rgcdpdpt_pickup_name', item.name);
      setHidden('rgcdpdpt_pickup_address', item.address);
      setHidden('rgcdpdpt_pickup_zip', item.zip);
      setHidden('rgcdpdpt_pickup_city', item.city);
      setHidden('rgcdpdpt_pickup_country', item.country || 'PRT');
      setHidden('rgcdpdpt_pickup_latitude', item.latitude);
      setHidden('rgcdpdpt_pickup_longitude', item.longitude);

      selectedCode = item.code || '';
      widget.setAttribute('data-selected-code', selectedCode);
      summary.innerHTML = '<strong>Ponto selecionado:</strong> '
        + '<span class="rgcdpdpt-selected-name">' + escapeHtml(item.name) + ' (' + escapeHtml(item.code) + ')</span>'
        + '<small class="rgcdpdpt-selected-address">' + escapeHtml(((item.address || '') + ' ' + (item.zip || '') + ' ' + (item.city || '')).trim()) + '</small>'; 

      var formData = new URLSearchParams();
      formData.append('ajax', '1');
      formData.append('action', 'save');
      formData.append('pickup_code', item.code || '');
      formData.append('pickup_name', item.name || '');
      formData.append('pickup_address', item.address || '');
      formData.append('pickup_zip', item.zip || '');
      formData.append('pickup_city', item.city || '');
      formData.append('pickup_country', item.country || 'PRT');
      formData.append('pickup_latitude', item.latitude || '');
      formData.append('pickup_longitude', item.longitude || '');

      postForm(endpoint, formData).catch(function () {
        results.innerHTML = '<div class="alert alert-danger">Não foi possível guardar o ponto Pickup selecionado.</div>';
      });
    }

    function focusMapOnItem(item, openPopup) {
      if (!map || !item || !itemHasCoordinates(item)) {
        return;
      }

      var lat = parseCoordinate(item.latitude);
      var lng = parseCoordinate(item.longitude);
      var nextZoom = Math.min(19, Math.max(map.getZoom() || 0, 17));
      if (typeof map.flyTo === 'function') {
        map.flyTo([lat, lng], nextZoom, {animate: true, duration: 0.55});
      } else {
        map.setView([lat, lng], nextZoom, {animate: true});
      }
      setTimeout(function () {
        map.invalidateSize();
      }, 120);

      if (openPopup && markersByCode[item.code]) {
        markersByCode[item.code].openPopup();
      }
    }

    function selectItem(item, persist, openPopup) {
      if (!item) {
        return;
      }

      select.value = item.code || '';
      focusMapOnItem(item, openPopup);

      updateMapActionState();

      if (persist) {
        saveSelection(item);
      }
    }

    function renderSelect(items) {
      var html = '<option value="">Selecione um ponto Pickup</option>';
      items.forEach(function (item) {
        html += '<option value="' + escapeHtml(item.code || '') + '"'
          + ' data-latitude="' + escapeHtml(item.latitude || '') + '"'
          + ' data-longitude="' + escapeHtml(item.longitude || '') + '">'
          + escapeHtml(labelForItem(item))
          + '</option>';
      });

      select.innerHTML = html;
      select.disabled = false;
      selectWrap.style.display = 'block';
    }

    function renderMap(items) {
      var pointsWithCoordinates = items.filter(itemHasCoordinates);

      if (!pointsWithCoordinates.length) {
        setMapPlaceholder('A DPD devolveu pontos Pickup, mas sem coordenadas para apresentar no mapa. Use a lista acima.');
        results.innerHTML += '<div class="alert alert-warning rgcdpdpt-map-warning">A DPD devolveu pontos Pickup sem coordenadas. A seleção pela lista continua disponível.</div>';
        return;
      }

      mapWrap.style.display = 'block';
      mapContainer.innerHTML = '';

      loadLeaflet()
        .then(function () {
          if (!window.L) {
            throw new Error('Leaflet indisponível.');
          }

          if (!map) {
            map = window.L.map(mapContainer, {
              zoomControl: true,
              scrollWheelZoom: true,
              doubleClickZoom: true,
              boxZoom: true,
              keyboard: true,
              touchZoom: true,
              dragging: true
            });

            window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
              maxZoom: 19,
              attribution: '&copy; OpenStreetMap contributors'
            }).addTo(map);
          }

          if (markerGroup) {
            markerGroup.clearLayers();
          } else {
            markerGroup = window.L.layerGroup().addTo(map);
          }

          markersByCode = {};
          var bounds = [];
          var pickupMarkerIcon = null;

          if (pickupMarkerIconUrl && window.L && typeof window.L.icon === 'function') {
            pickupMarkerIcon = window.L.icon({
              iconUrl: pickupMarkerIconUrl,
              iconSize: [42, 56],
              iconAnchor: [21, 56],
              popupAnchor: [0, -52]
            });
          }

          pointsWithCoordinates.forEach(function (item) {
            var lat = parseCoordinate(item.latitude);
            var lng = parseCoordinate(item.longitude);
            var popup = '<strong>' + escapeHtml(item.name || 'DPD Pickup') + '</strong><br>'
              + escapeHtml(item.address || '') + '<br>'
              + escapeHtml(((item.zip || '') + ' ' + (item.city || '')).trim())
              + '<br><button type="button" class="rgcdpdpt-map-select" data-code="' + escapeHtml(item.code || '') + '">Selecionar este ponto</button>';

            var markerOptions = pickupMarkerIcon ? {icon: pickupMarkerIcon} : {};
            var marker = window.L.marker([lat, lng], markerOptions).bindPopup(popup);
            marker.on('click', function () {
              selectItem(item, false, false);
            });
            marker.on('popupopen', function (popupEvent) {
              var popupElement = popupEvent && popupEvent.popup && typeof popupEvent.popup.getElement === 'function'
                ? popupEvent.popup.getElement()
                : null;
              var popupButton = popupElement ? popupElement.querySelector('.rgcdpdpt-map-select') : null;

              if (!popupButton || popupButton.dataset.rgcdpdptBound === '1') {
                return;
              }

              popupButton.dataset.rgcdpdptBound = '1';
              popupButton.addEventListener('click', function (event) {
                event.preventDefault();
                event.stopPropagation();
                if (typeof event.stopImmediatePropagation === 'function') {
                  event.stopImmediatePropagation();
                }

                selectItem(item, true, false);
                if (map && typeof map.closePopup === 'function') {
                  map.closePopup();
                }
              });
            });
            marker.addTo(markerGroup);
            markersByCode[item.code] = marker;
            bounds.push([lat, lng]);
          });

          lastBounds = bounds.slice();
          setMapToolsVisible(true);

          if (bounds.length === 1) {
            map.setView(bounds[0], 17);
          } else {
            map.fitBounds(bounds, {padding: [42, 42], maxZoom: 16});
          }

          setTimeout(function () {
            map.invalidateSize();
          }, 150);

          if (selectedCode) {
            selectItem(getItemByCode(selectedCode), false, true);
          }
        })
        .catch(function () {
          setMapPlaceholder('Não foi possível carregar o mapa. Use a lista acima para selecionar o ponto Pickup.');
          results.innerHTML += '<div class="alert alert-warning rgcdpdpt-map-warning">Não foi possível carregar o mapa. A seleção pela lista continua disponível.</div>';
        });
    }

    function renderItems(items) {
      pickupItems = sortItemsByPostcodeProximity(Array.isArray(items) ? items : [], zipInput.value || '');
      markersByCode = {};

      if (!pickupItems.length) {
        resetSelect('Nenhum ponto Pickup encontrado');
        setMapPlaceholder('Nenhum ponto Pickup encontrado para este código postal.');
        results.innerHTML = '<div class="alert alert-warning">Nenhum ponto Pickup encontrado.</div>';
        return;
      }

      results.innerHTML = '<div class="alert alert-success">Foram encontrados ' + pickupItems.length + ' pontos Pickup. Selecione na lista ou diretamente no mapa.</div>';
      renderSelect(pickupItems);
      renderMap(pickupItems);
      updateMapActionState();

      if (selectedCode && getItemByCode(selectedCode)) {
        select.value = selectedCode;
        updateMapActionState();
      } else if (selectedCode) {
        selectedCode = '';
        widget.setAttribute('data-selected-code', '');
        summary.innerHTML = '';
      }
    }

    resetSelect();
    setMapPlaceholder();

    lookupBtn.addEventListener('click', function (event) {
      if (event) {
        event.preventDefault();
        event.stopPropagation();
      }

      var zip = (zipInput.value || '').trim();
      if (!zip) {
        results.innerHTML = '<div class="alert alert-warning">Indique um código postal.</div>';
        return;
      }

      results.innerHTML = '<div class="alert alert-info">A procurar pontos Pickup...</div>';
      resetSelect('A procurar pontos Pickup...');
      setMapPlaceholder('A procurar pontos Pickup...');

      var query = new URLSearchParams();
      query.append('ajax', '1');
      query.append('action', 'list');
      query.append('zip', zip);
      query.append('address', deliveryAddress);
      query.append('city', deliveryCity);

      postForm(endpoint, query)
        .then(function (response) {
          return response.json();
        })
        .then(function (json) {
          if (!json.ok) {
            throw new Error(json.message || 'Erro ao consultar pontos Pickup.');
          }
          renderItems(json.items || []);
        })
        .catch(function (error) {
          resetSelect('Erro ao carregar pontos Pickup');
          setMapPlaceholder('Erro ao carregar pontos Pickup.');
          results.innerHTML = '<div class="alert alert-danger">' + escapeHtml(error.message) + '</div>';
        });
    });

    if (zoomInBtn) {
      zoomInBtn.addEventListener('click', function (event) {
        event.preventDefault();
        event.stopPropagation();
        if (map) {
          map.zoomIn();
          setTimeout(function () { map.invalidateSize(); }, 80);
        }
      });
    }

    if (zoomOutBtn) {
      zoomOutBtn.addEventListener('click', function (event) {
        event.preventDefault();
        event.stopPropagation();
        if (map) {
          map.zoomOut();
          setTimeout(function () { map.invalidateSize(); }, 80);
        }
      });
    }

    if (fitBtn) {
      fitBtn.addEventListener('click', function (event) {
        event.preventDefault();
        event.stopPropagation();
        fitMapToCurrentBounds();
      });
    }

    if (selectedBtn) {
      selectedBtn.addEventListener('click', function (event) {
        event.preventDefault();
        event.stopPropagation();
        var item = getItemByCode(select.value || selectedCode);
        if (item) {
          focusMapOnItem(item, true);
        }
      });
    }

    select.addEventListener('change', function (event) {
      if (event) {
        event.stopPropagation();
      }

      var item = getItemByCode(select.value);
      selectItem(item, true, true);
    });

    function handleMapSelectButton(event) {
      if (!event || !event.target || typeof event.target.closest !== 'function') {
        return;
      }

      var button = event.target.closest('.rgcdpdpt-map-select');
      if (!button || !widget.contains(button)) {
        return;
      }

      event.preventDefault();
      event.stopPropagation();
      if (typeof event.stopImmediatePropagation === 'function') {
        event.stopImmediatePropagation();
      }

      var item = getItemByCode(button.getAttribute('data-code'));
      selectItem(item, true, false);

      if (map && typeof map.closePopup === 'function') {
        map.closePopup();
      }
    }

    mapContainer.addEventListener('click', handleMapSelectButton);
    document.addEventListener('click', handleMapSelectButton, true);


    zipInput.addEventListener('keydown', function (event) {
      if (event.key === 'Enter') {
        event.preventDefault();
        lookupBtn.click();
      }
    });
  }

  function removeDuplicateFallbackWhenPrimaryExists() {
    var primaryWidget = document.querySelector('.rgcdpdpt-pickup-widget[data-is-fallback="0"]');
    if (!primaryWidget) {
      return;
    }

    document.querySelectorAll('.rgcdpdpt-pickup-widget[data-is-fallback="1"]').forEach(function (widget) {
      widget.style.display = 'none';
    });
  }

  function initWidgets() {
    document.querySelectorAll('.rgcdpdpt-pickup-widget').forEach(function (widget) { bindWidget(widget); updatePickupWidgetVisibility(widget); });
    removeDuplicateFallbackWhenPrimaryExists();
    refreshFallbackVisibility();
  }

  document.addEventListener('DOMContentLoaded', initWidgets);
  document.addEventListener('change', function (event) {
    if (event.target && event.target.matches('input[type="radio"][name^="delivery_option"]')) {
      initWidgets();
    }
  });

  if (window.prestashop && typeof window.prestashop.on === 'function') {
    window.prestashop.on('updatedDeliveryForm', initWidgets);
    window.prestashop.on('updatedCheckout', initWidgets);
    window.prestashop.on('changedCheckoutStep', initWidgets);
  }

  var observer = new MutationObserver(function () {
    initWidgets();
  });

  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });
})();
