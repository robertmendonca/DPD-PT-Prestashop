(function () {
  function getTabLinkFromEventTarget(target) {
    while (target && target !== document) {
      if (target.matches && target.matches('.rgcdpdpt-admin-tabs a[data-toggle="tab"]')) {
        return target;
      }
      target = target.parentNode;
    }
    return null;
  }

  function setActiveTab(hash, updateHash) {
    if (!hash || hash.indexOf('#rgcdpdpt-') !== 0) {
      return false;
    }

    var link = document.querySelector('.rgcdpdpt-admin-tabs a[href="' + hash + '"]');
    var pane = document.querySelector(hash);
    if (!link || !pane) {
      return false;
    }

    if (window.jQuery && typeof window.jQuery.fn.tab === 'function') {
      window.jQuery(link).tab('show');
    } else {
      var tabs = document.querySelectorAll('.rgcdpdpt-admin-tabs li');
      var panes = document.querySelectorAll('.rgcdpdpt-tab-content .tab-pane');

      for (var i = 0; i < tabs.length; i++) {
        tabs[i].classList.remove('active');
      }
      for (var j = 0; j < panes.length; j++) {
        panes[j].classList.remove('active');
      }

      link.parentNode.classList.add('active');
      pane.classList.add('active');
    }

    try {
      window.localStorage.setItem('rgcdpdptActiveAdminTab', hash);
    } catch (e) {}

    if (updateHash && window.history && window.history.replaceState) {
      window.history.replaceState(null, document.title, hash);
    }

    return true;
  }

  document.addEventListener('DOMContentLoaded', function () {
    document.addEventListener('click', function (event) {
      var link = getTabLinkFromEventTarget(event.target);
      if (!link) {
        return;
      }

      event.preventDefault();
      setActiveTab(link.getAttribute('href'), true);
    });

    var storedTab = '';
    try {
      storedTab = window.localStorage.getItem('rgcdpdptActiveAdminTab') || '';
    } catch (e) {}

    setActiveTab(window.location.hash || storedTab || '#rgcdpdpt-dpd', false);
  });
})();
