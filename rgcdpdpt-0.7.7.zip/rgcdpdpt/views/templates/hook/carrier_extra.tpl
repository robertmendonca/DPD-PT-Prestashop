<div class="rgcdpdpt-pickup-widget{if !empty($rgcdpdpt_is_fallback)} rgcdpdpt-pickup-fallback{/if}"
     data-pickup-url="{$pickup_ajax_url|escape:'htmlall':'UTF-8'}"
     data-selected-code="{$selected_pickup.pickup_code|default:''|escape:'htmlall':'UTF-8'}"
     data-is-fallback="{if !empty($rgcdpdpt_is_fallback)}1{else}0{/if}"
     data-pickup-carrier-id="{$rgcdpdpt_pickup_carrier_id|default:0|intval}"
     data-pickup-carrier-ref="{$rgcdpdpt_pickup_carrier_ref|default:0|intval}"
     data-pickup-marker-icon="{$rgcdpdpt_pickup_marker_icon|default:''|escape:'htmlall':'UTF-8'}"
     data-delivery-address="{$delivery_address|default:''|escape:'htmlall':'UTF-8'}"
     data-delivery-city="{$delivery_city|default:''|escape:'htmlall':'UTF-8'}"
     data-instance="{$rgcdpdpt_instance|default:'extra'|escape:'htmlall':'UTF-8'}">
  <div class="alert alert-info rgcdpdpt-help">
    Ao escolher DPD Pickup, os pontos são carregados automaticamente com o código postal da morada de entrega. Use o botão apenas se alterar o código postal.
  </div>

  <div class="form-group">
    <label for="rgcdpdpt_zip_lookup">Código postal</label>
    <div class="rgcdpdpt-inline">
      <input type="text"
             class="form-control"
             id="rgcdpdpt_zip_lookup"
             value="{$delivery_postcode|default:''|escape:'htmlall':'UTF-8'}"
             placeholder="0000-000" />
      <button type="button" class="btn btn-primary" id="rgcdpdpt_lookup_btn">Procurar pontos Pickup</button>
    </div>
  </div>

  <div id="rgcdpdpt_pickup_results" class="rgcdpdpt-pickup-status"></div>

  <div class="form-group rgcdpdpt-pickup-selector" id="rgcdpdpt_pickup_selector_wrap">
    <label for="rgcdpdpt_pickup_select">Ponto Pickup</label>
    <select class="form-control" id="rgcdpdpt_pickup_select" disabled="disabled">
      <option value="">Pesquise um código postal para carregar os pontos Pickup</option>
    </select>
  </div>

  <div class="rgcdpdpt-selected" id="rgcdpdpt_selected_summary">
    {if !empty($selected_pickup.pickup_code)}
      <strong>Ponto selecionado:</strong>
      <span class="rgcdpdpt-selected-name">{$selected_pickup.pickup_name|escape:'htmlall':'UTF-8'} ({$selected_pickup.pickup_code|escape:'htmlall':'UTF-8'})</span>
      <small class="rgcdpdpt-selected-address">
        {$selected_pickup.pickup_address|default:''|escape:'htmlall':'UTF-8'}
        {$selected_pickup.pickup_zip|default:''|escape:'htmlall':'UTF-8'}
        {$selected_pickup.pickup_city|default:''|escape:'htmlall':'UTF-8'}
      </small>
    {/if}
  </div>

  <div class="rgcdpdpt-map-wrap" id="rgcdpdpt_pickup_map_wrap">
    <div class="rgcdpdpt-map-tools" id="rgcdpdpt_map_tools" style="display:none;">
      <button type="button" class="rgcdpdpt-map-tool" id="rgcdpdpt_map_zoom_in" aria-label="Aproximar mapa">+</button>
      <button type="button" class="rgcdpdpt-map-tool" id="rgcdpdpt_map_zoom_out" aria-label="Afastar mapa">-</button>
      <button type="button" class="rgcdpdpt-map-tool rgcdpdpt-map-tool-text" id="rgcdpdpt_map_fit">Ver todos</button>
      <button type="button" class="rgcdpdpt-map-tool rgcdpdpt-map-tool-text" id="rgcdpdpt_map_selected" disabled="disabled">Ver selecionado</button>
      <span class="rgcdpdpt-map-hint">Pode arrastar, usar scroll do rato, duplo clique ou os controlos do mapa.</span>
    </div>
    <div id="rgcdpdpt_pickup_map" class="rgcdpdpt-pickup-map" aria-label="Mapa dos pontos DPD Pickup">
      <div class="rgcdpdpt-map-placeholder">O mapa será carregado depois da pesquisa.</div>
    </div>
    <small class="form-text text-muted rgcdpdpt-map-note">
      Se a DPD devolver pontos sem coordenadas, eles continuam disponíveis na lista.
    </small>
  </div>

  <input type="hidden" name="rgcdpdpt_pickup_code" id="rgcdpdpt_pickup_code" value="{$selected_pickup.pickup_code|default:''|escape:'htmlall':'UTF-8'}">
  <input type="hidden" name="rgcdpdpt_pickup_name" id="rgcdpdpt_pickup_name" value="{$selected_pickup.pickup_name|default:''|escape:'htmlall':'UTF-8'}">
  <input type="hidden" name="rgcdpdpt_pickup_address" id="rgcdpdpt_pickup_address" value="{$selected_pickup.pickup_address|default:''|escape:'htmlall':'UTF-8'}">
  <input type="hidden" name="rgcdpdpt_pickup_zip" id="rgcdpdpt_pickup_zip" value="{$selected_pickup.pickup_zip|default:''|escape:'htmlall':'UTF-8'}">
  <input type="hidden" name="rgcdpdpt_pickup_city" id="rgcdpdpt_pickup_city" value="{$selected_pickup.pickup_city|default:''|escape:'htmlall':'UTF-8'}">
  <input type="hidden" name="rgcdpdpt_pickup_country" id="rgcdpdpt_pickup_country" value="{$selected_pickup.pickup_country|default:'PRT'|escape:'htmlall':'UTF-8'}">
  <input type="hidden" name="rgcdpdpt_pickup_latitude" id="rgcdpdpt_pickup_latitude" value="{$selected_pickup.pickup_latitude|default:''|escape:'htmlall':'UTF-8'}">
  <input type="hidden" name="rgcdpdpt_pickup_longitude" id="rgcdpdpt_pickup_longitude" value="{$selected_pickup.pickup_longitude|default:''|escape:'htmlall':'UTF-8'}">
</div>
