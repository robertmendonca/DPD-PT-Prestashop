<?php
class DpdZoneResolver
{
    public const MAINLAND = 'mainland';
    public const MADEIRA = 'madeira';
    public const AZORES = 'azores';

    public static function resolveByPostcode($postcode)
    {
        $digits = preg_replace('/[^0-9]/', '', (string) $postcode);
        if (strlen($digits) < 4) {
            return self::MAINLAND;
        }

        $prefix = (int) substr($digits, 0, 4);

        if ($prefix >= 9000 && $prefix <= 9399) {
            return self::MADEIRA;
        }

        if (($prefix >= 9500 && $prefix <= 9699) || ($prefix >= 9700 && $prefix <= 9999)) {
            return self::AZORES;
        }

        return self::MAINLAND;
    }

    public static function resolveFromAddress(Address $address)
    {
        $country = new Country((int) $address->id_country);
        if (!Validate::isLoadedObject($country)) {
            return self::MAINLAND;
        }

        if (Tools::strtoupper($country->iso_code) !== 'PT') {
            return null;
        }

        return self::resolveByPostcode($address->postcode);
    }
}
