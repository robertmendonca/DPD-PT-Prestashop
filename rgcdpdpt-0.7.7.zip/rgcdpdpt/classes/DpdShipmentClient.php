<?php
class DpdShipmentClient
{
    public function createShipment(array $payload)
    {
        $token = (new DpdAuthClient())->getAccessToken();
        $url = trim((string) DpdConfig::get('SHIPMENT_URL'));
        if ($url === '') {
            throw new Exception('Shipment URL not configured.');
        }

        $ch = curl_init($url);
        $body = json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 60,
            CURLOPT_CONNECTTIMEOUT => 20,
            CURLOPT_POSTFIELDS => $body,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_USERAGENT => 'RGC-DPD-PT-Prestashop/' . (defined('_PS_VERSION_') ? _PS_VERSION_ : 'unknown'),
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $token,
                'Content-Type: application/json',
                'Accept: application/json',
                'Connection: close',
                'Expect:',
            ],
        ]);

        $raw = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($errno) {
            DpdLogRepository::add('error', 'DPD shipment curl error', 'shipment', 0, [
                'curl_errno' => (int) $errno,
                'curl_error' => $error,
                'http_status' => $status,
            ]);

            throw new Exception('DPD shipment curl error [' . (int) $errno . ']: ' . $error);
        }

        $decoded = json_decode((string) $raw, true);
        if (!is_array($decoded)) {
            throw new Exception('DPD shipment invalid JSON response. HTTP ' . $status . '. Raw: ' . Tools::substr((string) $raw, 0, 500));
        }

        DpdLogRepository::add('info', 'Shipment request executed', 'shipment', 0, ['http_status' => $status]);

        return $decoded;
    }
}
