<?php
class DpdCarrierManager
{
    public const TYPE_HOME = 'home';
    public const TYPE_PICKUP = 'pickup';

    /** @var Module */
    protected $module;

    public function __construct(Module $module)
    {
        $this->module = $module;
    }

    public function installOrRepair()
    {
        DpdConfig::ensureDefaults();
        $ok = true;

        foreach (DpdConfig::serviceTypes() as $type) {
            if (DpdConfig::isServiceEnabled($type)) {
                $ok = $this->ensureCarrier($type, $this->getCarrierDelay($type)) && $ok;
            } else {
                $this->disableCarrier($type);
            }
        }

        return $ok;
    }

    public function syncDeliveryPrices()
    {
        $shops = Shop::getShops(true, null, true);

        foreach (DpdConfig::serviceTypes() as $type) {
            $meta = $this->getCarrierMeta($type, false);
            $idCarrier = (int) ($meta['id'] ?? 0);
            if ($idCarrier <= 0) {
                continue;
            }

            $carrier = new Carrier($idCarrier);
            if (!Validate::isLoadedObject($carrier)) {
                continue;
            }

            $carrier->is_free = 0;
            $carrier->shipping_external = 1;
            $carrier->shipping_handling = 0;
            $carrier->need_range = 1;
            $carrier->active = DpdConfig::isServiceEnabled($type) ? 1 : 0;
            $carrier->update();

            $this->ensureWeightRangeAndDeliveryRows($carrier, $shops, $type);
        }

        return true;
    }

    public function uninstall()
    {
        foreach (DpdConfig::serviceTypes() as $type) {
            $meta = $this->getCarrierMeta($type, false);
            $idCarrier = (int) ($meta['id'] ?? 0);

            if ($idCarrier <= 0) {
                continue;
            }

            $carrier = new Carrier($idCarrier);
            if (Validate::isLoadedObject($carrier)) {
                $carrier->deleted = 1;
                $carrier->active = 0;
                $carrier->update();
            }
        }

        return true;
    }

    public function getCarrierMeta($type, $repairIfNeeded = true)
    {
        $type = DpdConfig::normalizeServiceType($type);
        $keys = $this->getConfigKeys($type);
        if ($keys === null) {
            return ['id' => 0, 'id_reference' => 0, 'name' => ''];
        }

        $configuredId = (int) DpdConfig::get($keys['id'], 0);
        $configuredReference = (int) DpdConfig::get($keys['ref'], 0);
        $row = $this->resolveCarrierRow($type, $configuredId, $configuredReference);

        if ($row) {
            $carrier = new Carrier((int) $row['id_carrier']);
            if (Validate::isLoadedObject($carrier)) {
                $this->ensureCarrierReference($carrier);
                if (DpdConfig::isServiceEnabled($type)) {
                    $this->attachCarrierEverywhere($carrier, $type);
                }
                $this->persistCarrierMeta($type, $carrier);

                return [
                    'id' => (int) $carrier->id,
                    'id_reference' => (int) $carrier->id_reference,
                    'name' => (string) $carrier->name,
                ];
            }
        }

        if ($repairIfNeeded && DpdConfig::isServiceEnabled($type)) {
            if ($this->ensureCarrier($type, $this->getCarrierDelay($type))) {
                return $this->getCarrierMeta($type, false);
            }
        }

        return [
            'id' => $configuredId,
            'id_reference' => $configuredReference,
            'name' => $this->getCarrierName($type),
        ];
    }

    public function matchesType($carrierId, $carrierReference, $type, $carrierName = '')
    {
        $type = DpdConfig::normalizeServiceType($type);
        $meta = $this->getCarrierMeta($type);
        $carrierId = (int) $carrierId;
        $carrierReference = (int) $carrierReference;
        $carrierName = trim((string) $carrierName);

        if ($carrierId > 0 && $meta['id'] > 0 && $carrierId === (int) $meta['id']) {
            return true;
        }

        if ($carrierReference > 0 && $meta['id_reference'] > 0 && $carrierReference === (int) $meta['id_reference']) {
            return true;
        }

        return $carrierName !== '' && $carrierName === $this->getCarrierName($type);
    }

    public function getMatchedType($carrierId, $carrierReference = 0, $carrierName = '')
    {
        foreach (DpdConfig::serviceTypes() as $type) {
            if ($this->matchesType($carrierId, $carrierReference, $type, $carrierName)) {
                return $type;
            }
        }

        return '';
    }

    public function isPickupType($type)
    {
        return DpdConfig::isPickupService($type);
    }

    public function syncCarrierLogoForType($type, $carrierId = 0)
    {
        $type = DpdConfig::normalizeServiceType($type);
        $carrierId = (int) $carrierId;

        if ($carrierId <= 0) {
            $meta = $this->getCarrierMeta($type, false);
            $carrierId = (int) ($meta['id'] ?? 0);
        }

        if ($carrierId <= 0 || !defined('_PS_SHIP_IMG_DIR_')) {
            return true;
        }

        $source = $this->getCarrierLogoSource($type);
        if ($source === '' || !is_readable($source)) {
            return true;
        }

        $destination = rtrim(_PS_SHIP_IMG_DIR_, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $carrierId . '.jpg';
        $destinationDir = dirname($destination);

        if (!is_dir($destinationDir) || !is_writable($destinationDir)) {
            return true;
        }

        @copy($source, $destination);
        if (is_file($destination)) {
            @chmod($destination, 0644);
        }

        return true;
    }

    protected function ensureCarrier($type, $delay)
    {
        $type = DpdConfig::normalizeServiceType($type);
        $meta = $this->getCarrierMeta($type, false);
        $carrier = null;

        if (!empty($meta['id'])) {
            $carrier = new Carrier((int) $meta['id']);
            if (!Validate::isLoadedObject($carrier)) {
                $carrier = null;
            }
        }

        if (!$carrier) {
            $row = $this->resolveCarrierRow($type, 0, 0);
            if ($row) {
                $carrier = new Carrier((int) $row['id_carrier']);
                if (!Validate::isLoadedObject($carrier)) {
                    $carrier = null;
                }
            }
        }

        $delays = $this->buildDelays($delay);

        if (!$carrier) {
            $carrier = new Carrier();
            $carrier->name = $this->getCarrierName($type);
            $carrier->active = 1;
            $carrier->deleted = 0;
            $carrier->shipping_external = 1;
            $carrier->is_free = 0;
            $carrier->shipping_handling = 0;
            $carrier->need_range = 1;
            $carrier->is_module = 1;
            $carrier->external_module_name = $this->module->name;
            $carrier->range_behavior = 0;
            $carrier->shipping_method = Carrier::SHIPPING_METHOD_WEIGHT;
            $carrier->max_width = 0;
            $carrier->max_height = 0;
            $carrier->max_depth = 0;
            $carrier->max_weight = (float) DpdConfig::maxWeight();
            $carrier->grade = 0;
            $carrier->url = 'https://tracking.dpd.pt/track-and-trace?v1=' . '@';
            $carrier->delay = $delays;

            if (!$carrier->add()) {
                return false;
            }
        } else {
            $carrier->name = $this->getCarrierName($type);
            $carrier->active = 1;
            $carrier->deleted = 0;
            $carrier->shipping_external = 1;
            $carrier->is_free = 0;
            $carrier->shipping_handling = 0;
            $carrier->need_range = 1;
            $carrier->is_module = 1;
            $carrier->external_module_name = $this->module->name;
            $carrier->range_behavior = 0;
            $carrier->shipping_method = Carrier::SHIPPING_METHOD_WEIGHT;
            $carrier->max_weight = (float) DpdConfig::maxWeight();
            $carrier->url = 'https://tracking.dpd.pt/track-and-trace?v1=' . '@';
            $carrier->delay = $delays;
            $carrier->update();
        }

        $this->ensureCarrierReference($carrier);
        $this->attachCarrierEverywhere($carrier, $type);
        $this->persistCarrierMeta($type, $carrier);
        $this->syncCarrierLogoForType($type, (int) $carrier->id);

        return true;
    }

    protected function disableCarrier($type)
    {
        $meta = $this->getCarrierMeta($type, false);
        $idCarrier = (int) ($meta['id'] ?? 0);
        if ($idCarrier <= 0) {
            return true;
        }

        $carrier = new Carrier($idCarrier);
        if (Validate::isLoadedObject($carrier)) {
            $carrier->active = 0;
            $carrier->update();
        }

        return true;
    }

    protected function getCarrierLogoSource($type)
    {
        $filename = DpdConfig::isPickupService($type) ? 'carrier-pickup.jpg' : 'carrier-home.jpg';
        $path = dirname(__DIR__) . '/views/img/' . $filename;

        return is_readable($path) ? $path : '';
    }

    protected function buildDelays($delay)
    {
        $delays = [];
        foreach (Language::getLanguages(false) as $language) {
            $delays[(int) $language['id_lang']] = $delay;
        }

        return $delays;
    }

    protected function getCarrierDelay($type)
    {
        return DpdConfig::isPickupService($type) ? 'Entrega em ponto Pickup DPD' : 'Entrega DPD Home';
    }

    protected function getCarrierName($type)
    {
        return DpdConfig::serviceName($type);
    }

    protected function getConfigKeys($type)
    {
        $type = DpdConfig::normalizeServiceType($type);
        if (!DpdConfig::isKnownServiceType($type)) {
            return null;
        }

        return [
            'id' => DpdConfig::carrierIdKey($type),
            'ref' => DpdConfig::carrierRefKey($type),
        ];
    }

    protected function persistCarrierMeta($type, Carrier $carrier)
    {
        $keys = $this->getConfigKeys($type);
        if ($keys === null) {
            return;
        }

        Configuration::updateValue(DpdConfig::key($keys['id']), (int) $carrier->id);
        Configuration::updateValue(DpdConfig::key($keys['ref']), (int) $carrier->id_reference);
    }

    protected function resolveCarrierRow($type, $configuredId, $configuredReference)
    {
        $type = DpdConfig::normalizeServiceType($type);
        $configuredId = (int) $configuredId;
        $configuredReference = (int) $configuredReference;

        if ($configuredId > 0) {
            $row = $this->findCarrierRow('`id_carrier` = ' . $configuredId);
            if ($this->isUsableCarrierRow($row)) {
                return $row;
            }
        }

        if ($configuredReference > 0) {
            $row = $this->findCarrierRow(
                '`id_reference` = ' . $configuredReference
                . ' AND `external_module_name` = "' . pSQL($this->module->name) . '"',
                'deleted ASC, active DESC, id_carrier DESC'
            );
            if ($this->isUsableCarrierRow($row)) {
                return $row;
            }
        }

        $row = $this->findCarrierRow(
            '`name` = "' . pSQL($this->getCarrierName($type)) . '"'
            . ' AND `external_module_name` = "' . pSQL($this->module->name) . '"',
            'deleted ASC, active DESC, id_carrier DESC'
        );
        if ($this->isUsableCarrierRow($row)) {
            return $row;
        }

        return null;
    }

    protected function findCarrierRow($whereSql, $orderBy = 'id_carrier DESC')
    {
        $sql = 'SELECT `id_carrier`, `id_reference`, `name`, `external_module_name`, `deleted`, `active`
            FROM `' . _DB_PREFIX_ . 'carrier`
            WHERE ' . $whereSql . '
            ORDER BY ' . $orderBy;

        return Db::getInstance()->getRow($sql);
    }

    protected function isUsableCarrierRow($row)
    {
        return !empty($row)
            && isset($row['id_carrier'])
            && (string) ($row['external_module_name'] ?? '') === (string) $this->module->name;
    }

    protected function ensureCarrierReference(Carrier $carrier)
    {
        if ((int) $carrier->id_reference > 0) {
            return;
        }

        $carrier->id_reference = (int) $carrier->id;
        $carrier->update();
    }

    protected function attachCarrierEverywhere(Carrier $carrier, $type)
    {
        $shops = Shop::getShops(true, null, true);

        foreach ($shops as $idShop) {
            Db::getInstance()->insert('carrier_shop', [
                'id_carrier' => (int) $carrier->id,
                'id_shop' => (int) $idShop,
            ], false, true, Db::INSERT_IGNORE);

            Db::getInstance()->insert('module_carrier', [
                'id_module' => (int) $this->module->id,
                'id_shop' => (int) $idShop,
                'id_reference' => (int) $carrier->id_reference,
            ], false, true, Db::INSERT_IGNORE);
        }

        $context = Context::getContext();
        $idLang = (int) (($context && isset($context->language) && Validate::isLoadedObject($context->language)) ? $context->language->id : Configuration::get('PS_LANG_DEFAULT'));

        foreach (Group::getGroups($idLang) as $group) {
            Db::getInstance()->insert('carrier_group', [
                'id_carrier' => (int) $carrier->id,
                'id_group' => (int) $group['id_group'],
            ], false, true, Db::INSERT_IGNORE);
        }

        foreach (Zone::getZones(true) as $zone) {
            Db::getInstance()->insert('carrier_zone', [
                'id_carrier' => (int) $carrier->id,
                'id_zone' => (int) $zone['id_zone'],
            ], false, true, Db::INSERT_IGNORE);
        }

        $this->ensureWeightRangeAndDeliveryRows($carrier, $shops, $type);
        $this->attachRestrictedProducts($carrier);
    }

    protected function ensureWeightRangeAndDeliveryRows(Carrier $carrier, array $shops, $type)
    {
        $idCarrier = (int) $carrier->id;
        if ($idCarrier <= 0) {
            return;
        }

        $maxWeight = (float) DpdConfig::maxWeight();
        if ($maxWeight <= 0) {
            $maxWeight = 100000;
        }

        $idRangeWeight = (int) Db::getInstance()->getValue(
            'SELECT `id_range_weight`
             FROM `' . _DB_PREFIX_ . 'range_weight`
             WHERE `id_carrier` = ' . $idCarrier . '
             ORDER BY `delimiter2` DESC, `id_range_weight` DESC'
        );

        if ($idRangeWeight <= 0) {
            Db::getInstance()->insert('range_weight', [
                'id_carrier' => $idCarrier,
                'delimiter1' => 0,
                'delimiter2' => $maxWeight,
            ]);
            $idRangeWeight = (int) Db::getInstance()->Insert_ID();
        } else {
            Db::getInstance()->update('range_weight', [
                'delimiter1' => 0,
                'delimiter2' => $maxWeight,
            ], '`id_range_weight` = ' . $idRangeWeight);
        }

        if ($idRangeWeight <= 0) {
            return;
        }

        $fallbackPrice = DpdConfig::fallbackCarrierRate($type);

        foreach (Zone::getZones(true) as $zone) {
            $idZone = (int) $zone['id_zone'];

            foreach ($shops as $idShop) {
                $idShop = (int) $idShop;
                $exists = (int) Db::getInstance()->getValue(
                    'SELECT `id_delivery`
                     FROM `' . _DB_PREFIX_ . 'delivery`
                     WHERE `id_carrier` = ' . $idCarrier . '
                       AND `id_zone` = ' . $idZone . '
                       AND `id_shop` = ' . $idShop . '
                       AND `id_range_weight` = ' . $idRangeWeight . '
                     ORDER BY `id_delivery` DESC'
                );

                if ($exists > 0) {
                    Db::getInstance()->update('delivery', [
                        'price' => $fallbackPrice,
                    ], '`id_delivery` = ' . $exists);
                    continue;
                }

                Db::getInstance()->insert('delivery', [
                    'id_shop' => $idShop,
                    'id_shop_group' => 0,
                    'id_carrier' => $idCarrier,
                    'id_range_price' => 0,
                    'id_range_weight' => $idRangeWeight,
                    'id_zone' => $idZone,
                    'price' => $fallbackPrice,
                ]);
            }
        }
    }

    protected function attachRestrictedProducts(Carrier $carrier)
    {
        $idReference = (int) $carrier->id_reference;
        if ($idReference <= 0) {
            return;
        }

        Db::getInstance()->execute(
            'INSERT IGNORE INTO `' . _DB_PREFIX_ . 'product_carrier` (`id_product`, `id_carrier_reference`, `id_shop`)
             SELECT DISTINCT pc.`id_product`, ' . $idReference . ', pc.`id_shop`
             FROM `' . _DB_PREFIX_ . 'product_carrier` pc
             WHERE NOT EXISTS (
                 SELECT 1
                 FROM `' . _DB_PREFIX_ . 'product_carrier` existing_pc
                 WHERE existing_pc.`id_product` = pc.`id_product`
                   AND existing_pc.`id_shop` = pc.`id_shop`
                   AND existing_pc.`id_carrier_reference` = ' . $idReference . '
             )'
        );
    }
}
