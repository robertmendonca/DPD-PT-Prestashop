<?php
class DpdPickupRepository
{
    public static function saveForCart($idCart, array $pickup)
    {
        $existing = Db::getInstance()->getRow('
            SELECT *
            FROM `' . _DB_PREFIX_ . 'rgcdpd_pickup`
            WHERE `id_cart` = ' . (int) $idCart . '
            ORDER BY `id_rgcdpd_pickup` DESC
        ');

        $data = [
            'id_cart' => (int) $idCart,
            'pickup_code' => pSQL((string) $pickup['code']),
            'pickup_name' => pSQL((string) $pickup['name']),
            'pickup_address' => pSQL((string) ($pickup['address'] ?? '')),
            'pickup_zip' => pSQL((string) ($pickup['zip'] ?? '')),
            'pickup_city' => pSQL((string) ($pickup['city'] ?? '')),
            'pickup_country' => pSQL((string) ($pickup['country'] ?? '')),
            'raw_response' => pSQL(json_encode($pickup, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), true),
            'date_upd' => date('Y-m-d H:i:s'),
        ];

        if ($existing) {
            return Db::getInstance()->update('rgcdpd_pickup', $data, '`id_rgcdpd_pickup` = ' . (int) $existing['id_rgcdpd_pickup']);
        }

        $data['date_add'] = date('Y-m-d H:i:s');

        return Db::getInstance()->insert('rgcdpd_pickup', $data);
    }

    public static function assignOrderFromCart($idCart, $idOrder)
    {
        return Db::getInstance()->update(
            'rgcdpd_pickup',
            [
                'id_order' => (int) $idOrder,
                'date_upd' => date('Y-m-d H:i:s'),
            ],
            '`id_cart` = ' . (int) $idCart
        );
    }

    public static function getByCartId($idCart)
    {
        $row = Db::getInstance()->getRow('
            SELECT *
            FROM `' . _DB_PREFIX_ . 'rgcdpd_pickup`
            WHERE `id_cart` = ' . (int) $idCart . '
            ORDER BY `id_rgcdpd_pickup` DESC
        ');

        return self::hydrateRow($row);
    }

    public static function getByOrderId($idOrder)
    {
        $row = Db::getInstance()->getRow('
            SELECT *
            FROM `' . _DB_PREFIX_ . 'rgcdpd_pickup`
            WHERE `id_order` = ' . (int) $idOrder . '
            ORDER BY `id_rgcdpd_pickup` DESC
        ');

        return self::hydrateRow($row);
    }

    protected static function hydrateRow($row)
    {
        if (!is_array($row) || empty($row)) {
            return $row;
        }

        $raw = json_decode((string) ($row['raw_response'] ?? ''), true);
        if (is_array($raw)) {
            $row['pickup_latitude'] = isset($raw['latitude']) ? (string) $raw['latitude'] : '';
            $row['pickup_longitude'] = isset($raw['longitude']) ? (string) $raw['longitude'] : '';
        }

        return $row;
    }
}
