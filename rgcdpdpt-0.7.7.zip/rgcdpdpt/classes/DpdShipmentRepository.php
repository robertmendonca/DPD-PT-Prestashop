<?php
class DpdShipmentRepository
{
    public static function getByOrderId($idOrder)
    {
        return Db::getInstance()->getRow('
            SELECT *
            FROM `' . _DB_PREFIX_ . 'rgcdpd_shipment`
            WHERE `id_order` = ' . (int) $idOrder
        );
    }

    public static function saveForOrder($idOrder, $idCart, array $data)
    {
        $existing = self::getByOrderId($idOrder);
        $payload = [
            'id_cart' => (int) $idCart,
            'carrier_type' => pSQL((string) ($data['carrier_type'] ?? 'home')),
            'dpd_sub_account' => pSQL((string) ($data['dpd_sub_account'] ?? '')),
            'tracking_number' => pSQL((string) ($data['tracking_number'] ?? '')),
            'label_path' => pSQL((string) ($data['label_path'] ?? '')),
            'request_payload' => pSQL(is_string($data['request_payload'] ?? null) ? $data['request_payload'] : json_encode($data['request_payload'] ?? null, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), true),
            'response_payload' => pSQL(is_string($data['response_payload'] ?? null) ? $data['response_payload'] : json_encode($data['response_payload'] ?? null, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), true),
            'status' => pSQL((string) ($data['status'] ?? 'created')),
            'is_test' => !empty($data['is_test']) ? 1 : 0,
            'date_upd' => date('Y-m-d H:i:s'),
        ];

        if ($existing) {
            return Db::getInstance()->update('rgcdpd_shipment', $payload, '`id_rgcdpd_shipment` = ' . (int) $existing['id_rgcdpd_shipment']);
        }

        $payload['id_order'] = (int) $idOrder;
        $payload['date_add'] = date('Y-m-d H:i:s');

        return Db::getInstance()->insert('rgcdpd_shipment', $payload);
    }

    public static function updateTrackingNumber($idOrder, $trackingNumber)
    {
        return Db::getInstance()->update('rgcdpd_shipment', [
            'tracking_number' => pSQL((string) $trackingNumber),
            'date_upd' => date('Y-m-d H:i:s'),
        ], '`id_order` = ' . (int) $idOrder);
    }
}
